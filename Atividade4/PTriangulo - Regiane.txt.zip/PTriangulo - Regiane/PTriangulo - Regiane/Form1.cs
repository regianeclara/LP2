﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PTriangulo___Regiane
{
    public partial class frmTriangulo : Form
    {
        double ladoA, ladoB, ladoC;
        public frmTriangulo()
        {
            InitializeComponent();
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoA.Text, out ladoA))
                MessageBox.Show("Dado inválido");
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoB.Text, out ladoB))
                MessageBox.Show("Dado inválido");
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtLadoC.Text, out ladoC))
                MessageBox.Show("Dado inválido");
        }

        private void btnVerificar_Click(object sender, EventArgs e)
        {
            if ((!double.TryParse(txtLadoA.Text, out ladoA)) ||  (!double.TryParse(txtLadoB.Text, out ladoB)) || (!double.TryParse(txtLadoC.Text, out ladoC)))
                MessageBox.Show("Dados Inválidos");

            else 

            if ((ladoA < (ladoB + ladoC)) && (ladoA > Math.Abs(ladoB - ladoC)) &&
                (ladoB < (ladoA + ladoC)) && (ladoB > Math.Abs(ladoA - ladoC)) &&
                (ladoC < (ladoA + ladoB)) && (ladoC > Math.Abs(ladoA - ladoB)))
            {
                MessageBox.Show("Você tem um triângulo");
          
                if ((ladoA == ladoB) && (ladoB == ladoC))
                    MessageBox.Show("O triângulo é: Equilátero");


                else if ((ladoB == ladoC) || (ladoB == ladoA))
                    MessageBox.Show("O triângulo é: Isósceles");

                else

                    MessageBox.Show("O triângulo é: Escaleno");
            }
            else
            MessageBox.Show("Os dados não formam um triângulo");

        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Clear();
            txtLadoB.Clear();
            txtLadoC.Clear();
        }
    }
}
