﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PCampeonato
{
    public partial class Form1 : Form
    {

        public Form1()
        {

            InitializeComponent();
        }
        private void txtGols_Validated(object sender, EventArgs e)
        {

        }

        private void btnExibir_Click(object sender, EventArgs e)
        {

            int[,] matrizGols = new int[2, 3];
            string auxiliar = "";
            int saldoGols = 0;
           

            for (var i = 0; i < 2; i++)
            {
                for (var j = 0; j < 2; j++)
                {
                    if (j == 0)
                    {
                        auxiliar = Interaction.InputBox("Gols feitos");

                        if (int.TryParse(auxiliar, out matrizGols[i, j]))
                        {
                            if (matrizGols[i, j] < 0)
                            {
                                MessageBox.Show("Número Inválido");
                                j--;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Número Inválido");
                            j--;
                        }
                    }

                    if (j == 1)
                    {
                        auxiliar = Interaction.InputBox("Gols recebidos");

                        if (int.TryParse(auxiliar, out matrizGols[i, j]))
                        {
                            if (matrizGols[i, j] < 0)
                            {
                                MessageBox.Show("Número Inválido");
                                j--;
                            }
                        }
                        else
                        {
                            MessageBox.Show("Número Inválido");
                            j--;
                        }
                    }
                }
                matrizGols[i,2] = matrizGols[i,1] - matrizGols[i,0];

                lbxResultado.Items.Add("Time" + (i + 1) + matrizGols[i,2].ToString("N2"));
            }
        }

    }
}