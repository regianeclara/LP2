﻿namespace PFerramenta
{
    partial class frmSobre
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSobre));
            this.lblApresentacao = new System.Windows.Forms.Label();
            this.lblRegiane = new System.Windows.Forms.Label();
            this.lblLaisa = new System.Windows.Forms.Label();
            this.lblRa1 = new System.Windows.Forms.Label();
            this.lblRa2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // lblApresentacao
            // 
            this.lblApresentacao.AutoSize = true;
            this.lblApresentacao.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblApresentacao.Location = new System.Drawing.Point(301, 88);
            this.lblApresentacao.Name = "lblApresentacao";
            this.lblApresentacao.Size = new System.Drawing.Size(412, 29);
            this.lblApresentacao.TabIndex = 0;
            this.lblApresentacao.Text = "Esse projeto foi desenvolvido por:";
            // 
            // lblRegiane
            // 
            this.lblRegiane.AutoSize = true;
            this.lblRegiane.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRegiane.Location = new System.Drawing.Point(114, 197);
            this.lblRegiane.Name = "lblRegiane";
            this.lblRegiane.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.lblRegiane.Size = new System.Drawing.Size(117, 20);
            this.lblRegiane.TabIndex = 1;
            this.lblRegiane.Text = "Regiane Lara";
            // 
            // lblLaisa
            // 
            this.lblLaisa.AutoSize = true;
            this.lblLaisa.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblLaisa.Location = new System.Drawing.Point(842, 197);
            this.lblLaisa.Name = "lblLaisa";
            this.lblLaisa.Size = new System.Drawing.Size(123, 20);
            this.lblLaisa.TabIndex = 2;
            this.lblLaisa.Text = "Laísa Bortolini";
            // 
            // lblRa1
            // 
            this.lblRa1.AutoSize = true;
            this.lblRa1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblRa1.Location = new System.Drawing.Point(124, 226);
            this.lblRa1.Name = "lblRa1";
            this.lblRa1.Size = new System.Drawing.Size(85, 13);
            this.lblRa1.TabIndex = 3;
            this.lblRa1.Text = "0030482121012";
            // 
            // lblRa2
            // 
            this.lblRa2.AutoSize = true;
            this.lblRa2.Location = new System.Drawing.Point(864, 226);
            this.lblRa2.Name = "lblRa2";
            this.lblRa2.Size = new System.Drawing.Size(85, 13);
            this.lblRa2.TabIndex = 4;
            this.lblRa2.Text = "0030482011018";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(163, 374);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(786, 25);
            this.label1.TabIndex = 5;
            this.label1.Text = "Análise e Desenvolvimento de Sistemas - Faculdade de Tecnologia de Sorocaba";
            // 
            // frmSobre
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Azure;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1094, 688);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblRa2);
            this.Controls.Add(this.lblRa1);
            this.Controls.Add(this.lblLaisa);
            this.Controls.Add(this.lblRegiane);
            this.Controls.Add(this.lblApresentacao);
            this.DoubleBuffered = true;
            this.ForeColor = System.Drawing.SystemColors.InfoText;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frmSobre";
            this.Text = "frmSobre";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblApresentacao;
        private System.Windows.Forms.Label lblRegiane;
        private System.Windows.Forms.Label lblLaisa;
        private System.Windows.Forms.Label lblRa1;
        private System.Windows.Forms.Label lblRa2;
        private System.Windows.Forms.Label label1;
    }
}